Enrique Lira Martinez
A01023351

INSTALLATION

make

EXECUTION

Start server:
./server {port}

Start clients:
./client {host} {port}
