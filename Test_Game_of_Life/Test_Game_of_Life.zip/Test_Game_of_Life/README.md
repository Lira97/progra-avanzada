Enrique Lira Martinez
A01023351

INSTALLATION

make (The makefile has some modifications regarding the flags since we need to use the threads it is necessary to use the -fopenmp)

EXECUTION (for the execution of the program it is necessary to make use of some flags which receive the arguments in the following way)
    Game of life 
    . /game_of_life  {number of iteration} {name of file} {option of thread (1 = OMP, 2 = thread, other number = linear mode) }

    
    
    
